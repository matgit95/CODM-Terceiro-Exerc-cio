package com.example.NewProject

data class ProjectExampleItem ( val content: String, val date: String, val position: Int )