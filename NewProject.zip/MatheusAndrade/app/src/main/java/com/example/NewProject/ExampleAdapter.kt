package com.example.NewProject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.NewProject.ProjectExampleItem
import com.example.NewProject.R



class ExampleAdapter(
        private val exampleList: List<ProjectExampleItem>, private val listener: MainActivity ) :  RecyclerView.Adapter<ExampleAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate (R.layout.project_item, parent, false)

        return ViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = exampleList[position]

        holder.date.text = currentItem.date
        holder.content.text = currentItem.content
        holder.position.text = currentItem.position.toString()
    }
    override fun getItemCount() = exampleList.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
    View.OnClickListener, View.OnLongClickListener {
        val date: TextView = itemView.findViewById(R.id.date)
        val content: TextView = itemView.findViewById(R.id.content)
        val position: TextView = itemView.findViewById(R.id.position)

        init {
            itemView.setOnClickListener(this)
            itemView.setOnLongClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = bindingAdapterPosition
            if(position != RecyclerView.NO_POSITION) {
                listener.onItemClick(position)
            }
        }


        override fun onLongClick(v: View?): Boolean {
            val position = bindingAdapterPosition
            if(position != RecyclerView.NO_POSITION) {
                listener.onLongItemClick(position)
            }

            return true
        }


    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    interface OnLongClickListener {
        fun onLongItemClick(position: Int)
    }
}
