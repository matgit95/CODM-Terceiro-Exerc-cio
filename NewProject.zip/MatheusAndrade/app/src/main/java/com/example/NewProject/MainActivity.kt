package com.example.NewProject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(),
        ExampleAdapter.OnItemClickListener,
        ExampleAdapter.OnLongClickListener {
    private val exampleList = ArrayList<ProjectExampleItem>()
    private val adapter = ExampleAdapter(exampleList, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        val saveBtn = findViewById<Button>(R.id.saveButton)
        val clearBtn = findViewById<Button>(R.id.clearButton)
        val content: EditText = findViewById(R.id.content)
        val date: EditText = findViewById(R.id.date)
        var count = 0

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)

        fun clearForm() {
            content.text.clear()
            date.text.clear()
        }

        fun insertItem() {
            val newItem = ProjectExampleItem(
                content.text.toString(),
                date.text.toString(),
                count
            )
            if (count > exampleList.size) {
                count = exampleList.size
                exampleList.add(count, newItem)
            } else {
                exampleList.add(count, newItem)
            }

            adapter.notifyItemInserted(count)
        }

        clearBtn.setOnClickListener {
            clearForm()
        }

        saveBtn.setOnClickListener {
            if (content.text.isNotEmpty() && date.text.isNotEmpty()) {
                insertItem()
                count++
                clearForm()
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "O novo item precisa de um nome",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onItemClick(position: Int) {
        val clickedItem = exampleList[position]
        val date: EditText = findViewById(R.id.date)
        val content: EditText = findViewById(R.id.content)

        date.setText(clickedItem.date)
        content.setText(clickedItem.content)

        onLongItemClick(clickedItem.position)
    }

    override fun onLongItemClick(position: Int) {
        val clickedItem = exampleList[position]
        exampleList.remove(clickedItem)
        adapter.notifyItemRemoved(position)
    }
}